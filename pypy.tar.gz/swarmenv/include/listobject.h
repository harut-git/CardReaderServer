#define PyList_GET_ITEM(o, i) PyList_GetItem((PyObject*)(o), (i))
