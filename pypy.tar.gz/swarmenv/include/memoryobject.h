#ifndef Py_MEMORYOBJECT_H
#define Py_MEMORYOBJECT_H

#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif
#endif /* !Py_MEMORYOBJECT_H */
